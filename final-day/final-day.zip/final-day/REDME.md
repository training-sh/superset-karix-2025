
```
docker compose build --no-cache superset celery_worker
```

```
docker compose up --build
```

```
docker exec -it   celery_worker bash

```
docker exec -it superset_mysql bash
```

# Test mail settings for mailpit

```
docker exec -it superset_app bash
```

curl  http://superset:8088/superset/dashboard/5b12b583-8204-08e9-392c-422209c29787/?force=false&standalone=3


```
cd /samples

python send-mail.py
```

```
docker compose exec superset bash -c "hostname; echo '--- /etc/hosts ---'; cat /etc/hosts | sed -n '1,120p'"

docker compose exec celery_worker bash -lc "getent hosts superset || true; curl -sS -I http://superset:8088/health || curl -sS -I http://superset:8088 | head -n 15 || true"

```

curl http://superset:8088/superset/dashboard/1/

docker   exec -it celery_worker bash

```
docker   exec -it superset_app bash
```


```
docker   exec -it superset_app superset load_examples
```

```
# from host
docker compose exec superset_app python -m playwright --version
# or inside worker
docker compose exec celery_worker python -c "from playwright.sync_api import sync_playwright; print('ok')"

```

```
docker   logs  celery_worker



docker compose exec celery_worker bash -c "celery --app=superset.tasks.celery_app:app control ping"

docker compose exec celery_worker bash -c "celery --app=superset.tasks.celery_app:app inspect active_queues"

docker compose exec celery_worker bash -c "celery --app=superset.tasks.celery_app:app inspect registered"

docker compose exec superset mysql -uroot -pmysql_root_pass -e "SELECT id, name, active FROM alerts_report_schedule ORDER BY id DESC LIMIT 20;" superset || true


docker compose exec superset_mysql mysql -uroot -pmysql_root_pass -e "SELECT id, name, active FROM alerts_report_schedule ORDER BY id DESC LIMIT 20;" superset

```


 http://superset:8088/superset/dashboard/5b12b583-8204-08e9-392c-422209c29787/?force=false&standalone=3




--

JINJA PARAMETES

```
-- SELECT *.. where tenant_id={{tenant_id}} AND .....

-- a and b are parameters , jinja 2 parameter
-- where to mention the parameters
-- sql editor has param - this is for testing 
-- mention parameter in dataset 
-- superset_config 
-- in parameters JON { "a": 10,  "b": 2 }

SELECT {{a}} + {{b}}

```



```
chrome \
  --headless \
  --disable-gpu \
  --no-sandbox \
  --disable-dev-shm-usage \
  --force-device-scale-factor=2.0 \
  --high-dpi-support=2.0 \
  --disable-extensions \
  --window-size=1920,1080 \
  --screenshot=/tmp/test_screenshot.png \
  http://localhost:8088/login/
```


 cp /tmp/test_screenshot.png /app/superset_home


DBUS_SESSION_BUS_ADDRESS=/dev/null \

chrome \
  --headless \
  --disable-gpu \
  --no-sandbox \
  --disable-dev-shm-usage \
  --force-device-scale-factor=2.0 \
  --high-dpi-support=2.0 \
  --disable-extensions \
  --window-size=1920,1080 \
  --print-to-pdf=/tmp/test_report.pdf \
  "http://superset:8088/superset/dashboard/1/"

 cp /tmp/test_report.pdf /app/superset_home



 # adjust the service name if yours differs (superset_celery_worker / celery_worker)
docker compose logs --tail 200 -f celery_worker
# or to save to file
docker compose logs --tail 500 celery_worker > celery_logs.txt

docker compose logs --tail 200 -f celery_worker

docker exec -it celery_worker bash