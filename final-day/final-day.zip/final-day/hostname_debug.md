
    Learn more at htt# Exec into worker and test DNS + HTTP (PowerShell)
PS C:\superset\day5> docker compose exec celery_worker bash -c "echo '--- resolve superset ---'; getent hosts superset || true; echo '--- curl superset ---'; curl -sS -I --max-time 10 http://superset:8088 || true; \
>> echo '--- resolve superset_app ---'; getent hosts superset_app || true; echo '--- curl superset_app ---'; curl -sS -I --max-time 10 http://superset_app:8088 || true; \
>> echo '--- resolve localhost ---'; getent hosts localhost || true; echo '--- curl localhost ---'; curl -sS -I --max-time 10 http://localhost:8088 || true"
time="2025-10-22T13:09:32+05:30" level=warning msg="C:\\superset\\day5\\docker-compose.yml: `version` is obsolete"
--- resolve superset ---
172.19.0.7      superset
--- curl superset ---
HTTP/1.1 302 FOUND
Server: gunicorn
Date: Wed, 22 Oct 2025 07:39:32 GMT
Connection: keep-alive
Content-Type: text/html; charset=utf-8
Content-Length: 223
Location: /superset/welcome/
Vary: Accept-Encoding

--- resolve superset_app ---
172.19.0.7      superset_app
--- curl superset_app ---
HTTP/1.1 302 FOUND
Server: gunicorn
Date: Wed, 22 Oct 2025 07:39:32 GMT
Connection: keep-alive
Content-Type: text/html; charset=utf-8
Content-Length: 223
Location: /superset/welcome/
Vary: Accept-Encoding

--- resolve localhost ---
::1             localhost ip6-localhost ip6-loopback
--- curl localhost ---
curl: (7) Failed to connect to localhost port 8088 after 0 ms: Couldn't connect to server
PS C:\superset\day5>

