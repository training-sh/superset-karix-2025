# minimal superset_config.py
# SQLAlchemy connection for Superset metadata (Postgres)
# SQLALCHEMY_DATABASE_URI = "postgresql+psycopg2://superset:superset_pass@postgres:5432/superset"

#SQLALCHEMY_DATABASE_URI = "mysql+mysqlconnector://root:mysql_root_pass@mysql:3306/superset"
#SQLALCHEMY_DATABASE_URI = "mysql+mysqldb://root:mysql_root_pass@mysql:3306/superset"


SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:mysql_root_pass@mysql:3306/superset"



# Optional - recommend later to set CACHE_CONFIG, CELERY configs, etc.
# SECRET_KEY can be set via env; SUPERSET_SECRET_KEY env is used above.

# superset_config.py
import os
from cachelib.redis import RedisCache


# vi superset_config.py
# paste below at end of the file

# User session timeout start

# from datetime import timedelta

# # # Session timeout duration (in seconds)
# PERMANENT_SESSION_LIFETIME = timedelta(minutes=5)

# # # Enable session refresh on activity (optional)
# SESSION_REFRESH_EACH_REQUEST = True

# user session time out ends

# stop docker compose 

# docker compose down
# docker compose up

# Superset event config starts
# from superset.utils.log import DBEventLogger

# class MyCustomEventLogger(DBEventLogger):
#     def log(self, user_id, action, json_metadata, source_ip=None):
#         # Add your custom logging logic here
#         print(f"Custom Log: User {user_id} performed {action} with metadata {json_metadata}")
#         super().log(user_id, action, json_metadata, source_ip) # Call parent to log to DB

# EVENT_LOGGER = MyCustomEventLogger() # Custom one

# # Event logger(s)
# EVENT_LOGGER = DBEventLogger()       # writes to your metadata DB (audit)
# or use StdOutEventLogger() for debug
# EVENT_LOGGER = StdOutEventLogger()
# check postgreSQL logs table 

# superset event config ends

REDIS_HOST = os.environ.get("REDIS_HOST", "redis")
REDIS_PORT = int(os.environ.get("REDIS_PORT", 6379))

# ---------------------------
# Query Results backend (SQL Lab / async results storage)
# ---------------------------
# Use Redis for results; cachelib RedisCache instance is fine.
RESULTS_BACKEND = RedisCache(
    host=REDIS_HOST,
    port=REDIS_PORT,
    key_prefix="superset_results",
)

# # ---------------------------
# # Flask / App cache (UI caches)
# # ---------------------------

# for meta data, [dashboard, charts, datasets, users, roles ... in super set] - Postgres

CACHE_CONFIG = {
    "CACHE_TYPE": "redis",
    "CACHE_DEFAULT_TIMEOUT": 300,
    "CACHE_KEY_PREFIX": "superset_cache:",
    "CACHE_REDIS_HOST": REDIS_HOST,
    "CACHE_REDIS_PORT": REDIS_PORT,
    "CACHE_REDIS_DB": 1,
}

# # Superset data cache (some versions use DATA_CACHE_CONFIG)
# for Business data, mysql/tpch, clickhouse/tpch, etc

DATA_CACHE_CONFIG = {
    "CACHE_TYPE": "redis",
    "CACHE_DEFAULT_TIMEOUT": 300,
    "CACHE_KEY_PREFIX": "superset_data_cache:",
    "CACHE_REDIS_HOST": REDIS_HOST,
    "CACHE_REDIS_PORT": REDIS_PORT,
    "CACHE_REDIS_DB": 1,
}

# ---------------------------
# Celery broker/result backend (defined but workers optional)
# ---------------------------
# You can leave these here; without workers tasks won't be processed.
from celery.schedules import crontab

# Queue
CELERY_BROKER_URL = f"redis://{REDIS_HOST}:{REDIS_PORT}/0"
# BACKEND for resuls
CELERY_RESULT_BACKEND = f"redis://{REDIS_HOST}:{REDIS_PORT}/2"




class CeleryConfig:
    broker_url = CELERY_BROKER_URL # QUEUE, Async
    result_backend = CELERY_RESULT_BACKEND 
    timezone = "UTC"
    worker_prefetch_multiplier = 10
    task_acks_late = True
    beat_schedule = {
        "reports.scheduler": {
            "task": "reports.scheduler",
            "schedule": crontab(minute="*", hour="*"),   # every minute
        },
        "reports.prune_log": {
            "task": "reports.prune_log",
            "schedule": crontab(minute=10, hour=0),      # daily at 00:10
        },
    }


CELERY_CONFIG = CeleryConfig

# ---------------------------
# Keep secret key consistent
# ---------------------------
SECRET_KEY = os.environ.get("SUPERSET_SECRET_KEY", "please-change-me")


FEATURE_FLAGS = {"DASHBOARD_FILTERS_EXPERIMENTAL": True, 
                 "DASHBOARD_NATIVE_FILTERS_SET": True, 
                 "DASHBOARD_NATIVE_FILTERS": True, 
                 "DASHBOARD_CROSS_FILTERS": True, 
                 "ENABLE_TEMPLATE_PROCESSING": True,
                  "ALERT_REPORTS": True,
                 "SCHEDULED_QUERIES": True,
                 "EMAIL_NOTIFICATIONS": True
                 }


SCREENSHOT_LOCATE_WAIT = 100
SCREENSHOT_LOAD_WAIT = 600


def auth_func(driver, user):
    """
    This function automates Superset login for the headless browser (used in reports).
    The 'driver' is a Selenium webdriver instance.
    'user' is the Superset user running the report.
    """

    # Go to the login page
    driver.get("http://superset:8088/login/")

    # Wait for login page to load
    import time
    time.sleep(2)

    # Find username and password fields and login button
    username_box = driver.find_element("name", "username")
    password_box = driver.find_element("name", "password")

    # <input class="btn btn-primary btn-block" type="submit" value="Sign In">
                                
    # login_button = driver.find_element("css selector", 'button[type="submit"]')

    login_button = driver.find_element("css selector", 'input[type="submit"]')


    # Fill credentials (must match a real Superset user)
    username_box.send_keys("admin")
    password_box.send_keys("admin")

    # Submit the login form
    login_button.click()

    # Wait for Superset home/dashboard to load
    time.sleep(5)

    return driver


# Register your auth function
WEBDRIVER_AUTH_FUNC = auth_func

# And define the URL Superset should render for screenshots
# WEBDRIVER_BASEURL = "http://localhost:8088/"


# WebDriver configuration
# If you use Firefox or Playwright with Chrome, you can stick with default values
# If you use Chrome and are *not* using Playwright, then add the following WEBDRIVER_TYPE and WEBDRIVER_OPTION_ARGS
WEBDRIVER_TYPE = "chrome"

WEBDRIVER_OPTION_ARGS = [
    "--force-device-scale-factor=2.0",
    "--high-dpi-support=2.0",
    "--headless",
    "--disable-gpu",
    "--disable-dev-shm-usage",
    "--no-sandbox",
    "--disable-setuid-sandbox",
    "--disable-extensions",
]

# This is for internal use, you can keep http
WEBDRIVER_BASEURL = "http://superset:8088" # When running using docker compose use "http://superset_app:8088'
# This is the link sent to the recipient. Change to your domain, e.g. https://superset.mydomain.com
WEBDRIVER_BASEURL_USER_FRIENDLY = "http://superset:8088"

# # optional flags
# # Base URL that the webdriver will use to render pages (container host name is fine)
# WEBDRIVER_BASEURL = "http://superset:8088"  # use the service name & port used by containers

# WEBDRIVER_BASEURL_USER_FRIENDLY = "http://superset:8088"  # use the service name & port used by containers
from superset.tasks.types import FixedExecutor

ALERT_REPORTS_EXECUTORS = [FixedExecutor("admin")]

# Superset will warn if CSP is missing — silence that warning (won't enable CSP)
CONTENT_SECURITY_POLICY_WARNING = False

# Remove any CSP by setting to None (explicit)
CONTENT_SECURITY_POLICY = None

TALISMAN_ENABLED = False
# PREFERRED_URL_SCHEME = "http"
# ENABLE_PROXY_FIX = False

# superset_config.py (dev only)
WTF_CSRF_ENABLED = False

# WEBDRIVER_OPTION_ARGS = [
#     "--force-device-scale-factor=2.0",
#     "--high-dpi-support=2.0",
#     "--headless",
#     "--disable-gpu",
#     "--disable-dev-shm-usage",
#     "--no-sandbox",
#     "--disable-setuid-sandbox",
#     "--disable-extensions",
# ]

# WEBDRIVER_TYPE = "chrome"

ALERT_REPORTS_NOTIFICATION_DRY_RUN = False

REPORTS_USER = "admin"  # or your Superset username

# Optional but useful tuning
WEBDRIVER_USER = "admin"
WEBDRIVER_PASSWORD = "admin"
#WEBDRIVER_TYPE = "playwright"  # Superset will call playwright if available; this is informational
#WEBDRIVER_CHROMIUM_PATH = None  # usually not needed if playwright installed via pip + playwright install chromium

#WEBDRIVER_TYPE = "playwright" # "chrome"
WEBDRIVER_LOCATE_WAIT = 30    # seconds
# WEBDRIVER_TYPE =  "playwright"

# Task soft/hard time limits (in seconds)
CELERY_TASK_SOFT_TIME_LIMIT = 600    # soft limit (task can cleanup)
CELERY_TASK_TIME_LIMIT = 700         # hard limit (force kill)

# Optional: reduce concurrency to avoid resource exhaustion
CELERY_WORKER_CONCURRENCY = 8



# superset_config.py
CELERYD_TASK_TIME_LIMIT = 60 * 60 * 2       # 2 hours
CELERYD_TASK_SOFT_TIME_LIMIT = 60 * 60 * 1  # 1 hour soft limit
SUPERSET_WEBSERVER_TIMEOUT = 600            # depends on your proxy/gunicorn
GUNICORN_TIMEOUT = 600

# superset_config.py
WEBDRIVER_TIMEOUT = 180  # seconds
REPORTS_WEBDRIVER_TIMEOUT = 180  # if present in your version


# -----------------------
# Email / Alert configuration (for demo using Mailpit)
# -----------------------

# enable email notifications in Superset UI
EMAIL_NOTIFICATIONS = True

# SMTP server settings - for the demo we point to the mailpit service in docker-compose
# mailpit store email in local, can be see in http://localhost:8085
SMTP_HOST = "mailpit"        # docker-compose service name
SMTP_PORT = 1025

# SMTP_HOST = "mailrelay"        # docker-compose service name
# SMTP_PORT = 25

SMTP_STARTTLS = False
SMTP_SSL = False

# No auth for Mailpit by default (leave blank)
SMTP_USER = ""
SMTP_PASSWORD = ""

# Default "from" address for messages Superset sends
SMTP_MAIL_FROM = "superset-demo@example.test"

# optional: who receives system emails (admin or team address)
# DEFAULT_EMAIL = "admin@example.test"   # uncomment/modify if you want system emails forwarded



from flask import g

def current_user_region():
    print ("***current_user_region called***", g.user)
    return getattr(g.user, "region", None)

def get_usd_to_inr_price():
    return 86 # you can get this from some db

JINJA_CONTEXT_ADDONS = {
    "default_region": "ASIA",
    "default_nation": "Vietnam",
    "tenant_account": "tvs12345", # os.env['TENANT_ID']
    "current_fiscal_year": 2025,
    "current_user_region": current_user_region, # function is registered
    "get_usd_to_inr_price": get_usd_to_inr_price,
    "a": 1000,
    "b": 2000
}

