# create file
import socket, os, sys
host = os.getenv('SMTP_HOST','mailpit')
print('Trying to resolve host:', host)
try:
    ip = socket.gethostbyname(host)
    print('Resolved:', host, '->', ip)
except socket.gaierror as e:
    print('DNS ERROR (socket.gaierror):', e)
    sys.exit(2)
except Exception as e:
    print('Other error:', e)
    sys.exit(3)
