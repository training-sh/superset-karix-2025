import smtplib
from email.message import EmailMessage

SMTP_HOST = "mailrelay"   # if running compose locally and mapping ports
SMTP_PORT = 25

SMTP_HOST = "mailpit"   # if running compose locally and mapping ports
SMTP_PORT = 1025


msg = EmailMessage()
msg["From"] = "superset-demo@example.test"
msg["To"] = "fapon95854@nrlord.com"   # paste the temp-mail address
msg["Subject"] = "Test attachment from Superset demo"
msg.set_content("This is a test. See attached PNG and PDF.")

# attach PNG
with open("test.jpg", "rb") as f:
    data = f.read()
    msg.add_attachment(data, maintype="image", subtype="jpg", filename="chart.jpg")

# attach PDF (optional)
with open("test.pdf", "rb") as f:
    data = f.read()
    msg.add_attachment(data, maintype="application", subtype="pdf", filename="report.pdf")

s = smtplib.SMTP(SMTP_HOST, SMTP_PORT)
s.send_message(msg)
s.quit()
print("Sent test message to Mailpit (and it will be relayed). Check Mailpit UI and temp-mail inbox.")
