
```
docker compose build --no-cache superset celery_worker
```

```
docker compose up --build
```

```
docker exec -it superset_mysql bash
```

# Test mail settings for mailpit

```
docker exec -it superset_app bash
```
```
cd /samples

python send-mail.py
```

```
docker compose exec superset bash -c "hostname; echo '--- /etc/hosts ---'; cat /etc/hosts | sed -n '1,120p'"

docker compose exec celery_worker bash -lc "getent hosts superset || true; curl -sS -I http://superset:8088/health || curl -sS -I http://superset:8088 | head -n 15 || true"

```

```
docker   exec -it superset_app bash
```


```
docker   exec -it superset_app superset load_examples
```

```
# from host
docker compose exec superset_app python -m playwright --version
# or inside worker
docker compose exec celery_worker python -c "from playwright.sync_api import sync_playwright; print('ok')"

```

```
docker   logs  celery_worker



docker compose exec celery_worker bash -c "celery --app=superset.tasks.celery_app:app control ping"

docker compose exec celery_worker bash -c "celery --app=superset.tasks.celery_app:app inspect active_queues"

docker compose exec celery_worker bash -c "celery --app=superset.tasks.celery_app:app inspect registered"

docker compose exec superset mysql -uroot -pmysql_root_pass -e "SELECT id, name, active FROM alerts_report_schedule ORDER BY id DESC LIMIT 20;" superset || true


docker compose exec superset_mysql mysql -uroot -pmysql_root_pass -e "SELECT id, name, active FROM alerts_report_schedule ORDER BY id DESC LIMIT 20;" superset

```


 http://superset:8088/superset/dashboard/5b12b583-8204-08e9-392c-422209c29787/?force=false&standalone=3

